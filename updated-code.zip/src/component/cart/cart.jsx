import axios from "axios";
import React, { useEffect, useState } from "react";
const baseURL = "https://dummyjson.com";

const Cart = () => {
  const [cartData, setCartData] = useState([]);

  const fetchCartData = async () => {
    try {
      const res = await axios.get(`${baseURL}/carts`);
      console.log(res.data.carts[0].products[0], "cartResponse");
      setCartData(res.data.carts)
    } catch (err) {
      console.log(err);
    }
  };
  useEffect(() => {
    fetchCartData();
  }, []);

  return (
    <div style={{ color: "black" }}>
      <h2>This is the cart Data...</h2>
      {cartData.map((item)=>(
        <div key={item.id}>
          
        </div>
      ))}
    </div>
  );
};

export default Cart;
